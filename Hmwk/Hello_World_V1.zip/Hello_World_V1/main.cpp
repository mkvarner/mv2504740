/* 
 * File:   main.cpp
 * Author: Megan Varner
 * Created on June 24, 2014, 12:54 PM
 * Purpose:First program example
 */

//System level libraries

#include <iostream>
using namespace std;

//User defined libraries

//Global constants i.e avogadro's number, conversions, speed of light, ect.

//Function prototypes

//Execution begins here
int main(int argc, char** argv) {

    //Output a string
    
    cout<<"Hello World"<<endl;
    //Exit stage right
    
    return 0;
}

