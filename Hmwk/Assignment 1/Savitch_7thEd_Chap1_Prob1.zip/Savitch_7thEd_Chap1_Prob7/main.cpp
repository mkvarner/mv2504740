/* 
 * File:   main.cpp
 * Author: Megan Varner
 * Created on June 25, 2014, 7:34 PM
 * Purpose: Assignment 1
 */

#include <iostream>
using namespace std;
int main() 
{

    return 0;
}
