/* 
 * File:   main.cpp
 * Author: Megan Varner
 * Created on June 25, 2014, 7:34 PM
 * Write program that prints exactly what
 * was in book
 */

#include <iostream>
using namespace std;
int main() 
{
    cout <<"*****************************************************\n";
    cout <<"         C C C             S S S S          !!\n";
    cout <<"       C      C          S        S         !!\n";
    cout <<"      C                  S                  !!\n";
    cout <<"     C                    S                 !!\n";
    cout <<"     C                      S S S S         !!\n";
    cout <<"     C                              S       !!\n";
    cout <<"     C                                S     !!\n";
    cout <<"      C       C            S         S        \n";
    cout <<"        C C C                S S S S        OO\n";
    cout <<"*****************************************************:\n";
    cout <<"\n";
    cout <<"\n";
    cout <<"Computer Science is Cool Stuff!!!:\n";
    
    

    return 0;
}